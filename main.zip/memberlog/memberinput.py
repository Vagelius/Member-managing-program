import datetime



# FUNCTION FOR ENTERING MEMBERS,RECORDING THE TIME OF THE MEMBER ASIGMENT , INSERTING THEM IN A FILE
def EnterMember():
    print("EnterMember function was entered")
    member_count1=int(input("How many members do you want to asign?")) #MEMBERS THAT YOU WANT TO ASIGN IN THE MOMENT
    for i in range(member_count1):

       
        member_id = get_next_id()
        name_surname=input("Enter the name of the subscriber")
        time=datetime.datetime.now()
       
        print(f"Hello {name_surname}\n")
        print("Time of assignment:",time)
       
       
        with open("members.txt", "a") as file:
            file.write(f"Name,Surname: {name_surname}, Date of subscription: {time},ID:{member_id}\n")

# Function for numbering the ids
def get_next_id():
    try:
        with open("last_id.txt", "r") as file:
            last_id = int(file.read())
    except FileNotFoundError:
        last_id = 0

    next_id = last_id + 1

    with open("last_id.txt", "w") as file:
        file.write(str(next_id))

    return next_id
def DeleteMember():
    delete_id = input("Enter the ID to delete: ")

    try:
        with open("members.txt", "r") as file:
            lines = file.readlines()

        with open("members.txt", "w") as file:
            found = False

            for line in lines:
                if f"ID:{delete_id}" in line:
                    found = True
                    continue

                file.write(line)

        if found:
            print(f"Member with ID {delete_id} deleted.")
        else:
            print("ID not found.")

    except FileNotFoundError:
        print("members.txt does not exist.")



print("Welcome\n")
#ch1 = FIRST CHOICE
ch1=int(input("What do want to do?[ENTER A NEW MEMBER(1),DELETE A MEMBER(2)]"))

if(ch1==1):
    EnterMember()
elif(ch1==2):
    DeleteMember()